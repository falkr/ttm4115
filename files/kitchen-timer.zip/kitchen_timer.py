from appJar import gui
from stmpy import Machine, Driver

class KitchenTimer:

    def __init__(self):
        self.app = gui("Kitchen Timer", "160x340")
        self.app.setFont(14)
        self.app.addImage("x60", "timer/60_0.gif", 0, 0)
        self.app.addImage("x15", "timer/15_0.gif", 0, 1)
        self.app.addImage("x30", "timer/30_0.gif", 1, 1)
        self.app.addImage("x45", "timer/45_0.gif", 1, 0)
        self.app.addImage("plug", "timer/plug_off.gif", 2, 0, 2, 2)
        def press(button):
            self.stm.send('switch')
        self.app.addButton("Press Button", press, 4, 0, 2, 1)
        def terminate():
            self.stm.terminate()
            return True
        self.app.setStopFunction(terminate)

    def switch_led(self, led, brightness):
        self.app.setImage('x{}'.format(led), 'timer/{}_{}.gif'.format(led, brightness))

    def switch_plug(self, on):
        if on: 
            self.app.setImage('plug', "timer/plug_on.gif")
        else:
            self.app.setImage('plug', "timer/plug_off.gif")


t0 = {'source': 'initial', 'target': 'off'}
t1 = {'trigger': 'switch', 'source': 'off', 'target': 's15'}
t2 = {'trigger': 'switch', 'source': 's15', 'target': 's30'}
t3 = {'trigger': 'switch', 'source': 's30', 'target': 's45'}
t4 = {'trigger': 'switch', 'source': 's45', 'target': 's60'}
t5 = {'trigger': 'switch', 'source': 's60', 'target': 'off'}

tt1 = {'trigger': 't', 'source': 's15', 'target': 'off', 'effect': 'switch_led("15", "0")'}
tt2 = {'trigger': 't', 'source': 's30', 'target': 's15', 'effect': 'switch_led("30", "0")'}
tt3 = {'trigger': 't', 'source': 's45', 'target': 's30', 'effect': 'switch_led("45", "0")'}
tt4 = {'trigger': 't', 'source': 's60', 'target': 's45', 'effect': 'switch_led("60", "0")'}

off = {'name': 'off',
      'entry': 'switch_plug(False); switch_led("15", "0"); switch_led("30", "0"); switch_led("45", "0"); switch_led("60", "0")',
      'exit': 'switch_plug(True)'}

s15 = {'name': 's15',
      'entry': 'start_timer("t", 5000); start_timer("t1", 1000); switch_led("15", "1")',
      't1': 'switch_led("15", "2"); start_timer("t2", 1000)',
      't2': 'switch_led("15", "1"); start_timer("t1", 1000)'}

s30 = {'name': 's30',
      'entry': 'start_timer("t", 5000); start_timer("t1", 1000); switch_led("15", "1"); switch_led("30", "1")',
      't1': 'switch_led("30", "2"); start_timer("t2", 1000)',
      't2': 'switch_led("30", "1"); start_timer("t1", 1000)'}

s45 = {'name': 's45',
      'entry': 'start_timer("t", 5000); start_timer("t1", 1000); switch_led("30", "1"); switch_led("45", "1")',
      't1': 'switch_led("45", "2"); start_timer("t2", 1000)',
      't2': 'switch_led("45", "1"); start_timer("t1", 1000)'}

s60 = {'name': 's60',
      'entry': 'start_timer("t", 5000); start_timer("t1", 1000); switch_led("45", "1"); switch_led("60", "1")',
      't1': 'switch_led("60", "2"); start_timer("t2", 1000)',
      't2': 'switch_led("60", "1"); start_timer("t1", 1000)'}

k = KitchenTimer()

stm_kitchen = Machine(name='stm_kitchen', transitions=[t0, t1, t2, t3, t4, t5, tt1, tt2, tt3, tt4], obj=k, states=[off, s15, s30, s45, s60])
k.stm = stm_kitchen
driver = Driver()
driver.add_machine(stm_kitchen)
driver.start()

k.app.go()